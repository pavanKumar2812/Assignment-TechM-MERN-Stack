import React from "react";

/* const Movie = (props) => {
    return(
        <div>
            <h3>{props.name}</h3>
        
        </div>
    );
} */
const Movie = ({name, price}) => {
    return(
        <div>
            <h3>Movie: {name}</h3>
            <p>Cost: {price}</p>
        
        </div>
    );
}

export default Movie;