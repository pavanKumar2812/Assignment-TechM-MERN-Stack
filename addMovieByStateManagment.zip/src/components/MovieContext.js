import React,{useState , createContext} from "react";

export const MovieContext = createContext();

export const MovieProvider = (props) => {
    const [movies, setMovies] = useState([
        {
            name: 'Harry Potter',
            price: '₹100',
            id:'23124'
        },
        {
            name: 'Game of Thrones',
            price: '₹500',
            id:'23126'
        },
        {
            name: 'Ozark',
            price: '₹150',
            id:'23127'
        }
    ])
    return(
        <MovieContext.Provider value={[movies,setMovies]}>
            {props.children}
        </MovieContext.Provider>
    );
}