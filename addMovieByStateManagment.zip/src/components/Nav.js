import React, { useContext } from "react";
import { MovieContext } from "./MovieContext";

const Navbar = () => {
    const [movies,setMovies] = useContext(MovieContext);
    return(
        <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
            <div className="container">
                <a className="navbar-brand" href="#"><i>Pa!</i></a>
                <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span className="navbar-toggler-icon"></span>
                </button>
                <p className="text-light"> List of Movies: { movies.length }</p>
            </div>
        </nav>
    );
}

export default Navbar;