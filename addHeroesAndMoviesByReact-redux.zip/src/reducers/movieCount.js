const counterMovieReducer = (state = 0, action) => {
    switch(action.type){
        case 'ADDMOVIE':
            return state + 1;
        case 'REMOVEMOVIES':
            return state = 0;
        default:
            return state;
    }
}
export default counterMovieReducer;